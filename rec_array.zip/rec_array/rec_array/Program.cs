﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace rec_array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] a = new int[3, 3];
            int i, j;
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 3; j++)
                {
                    Console.Write("Enter value for "+i+"  " +j+ "Element :");
                    a[i,j] = Convert.ToInt32(Console.ReadLine());
                }
            }
            Console.Write("\n");
            foreach (int b in a)
            {
                Console.Write(b + " ");
            }
            Console.Read();
        }
    } 
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace switchcase
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("set Console color white=1");
            Console.WriteLine("set Console color black=2");
            Console.WriteLine("set Console color yellow=3");
            Console.WriteLine("set Console color darksyan=4");

            int n = Convert.ToInt32(Console.ReadLine());
            switch (n)
            { 
            case 1: Console.BackgroundColor=ConsoleColor.White;
            Console.Clear();
            break;
            case 2: Console.BackgroundColor=ConsoleColor.Black;
            Console.Clear();
            break;
            case 3: Console.BackgroundColor=ConsoleColor.Yellow;
            Console.Clear();
            break;
            case 4: Console.BackgroundColor = ConsoleColor.Magenta;
            Console.Clear();
            break;
             default:Console.Write("select 1,2,3,4");
                 break;
            }

            Console.Read();
        }
    }
}
